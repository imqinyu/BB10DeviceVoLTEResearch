@echo off
chcp 65001 >nul
title BB10 VoLTE Unicom Passport 1.1
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\BB10-VoLTE.ps1" -Action Check -ChooseKey
set result=%ERRORLEVEL%
echo.
pause
exit /b %result%
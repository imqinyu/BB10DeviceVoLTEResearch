@echo off
chcp 65001 >nul
title BlackBerry VoLTE Easy 1.0
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\BB10-VoLTE.ps1" -Action BerryOff
set result=%ERRORLEVEL%
echo.
pause
exit /b %result%
